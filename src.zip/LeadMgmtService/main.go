package main

import(
	"github.com/labstack/echo"
	config "LeadMgmtService/lib/configuration"
	database "LeadMgmtService/lib/database"
	create "LeadMgmtService/LeadMgmt/createlead"
)

func main() {
	initializeGormClient()
	e := echo.New()
	//database.DBClient.CreateLeadTable() 
	e.POST("/v1/leadsMgmt", create.CreateLeadHandler)
	e.Start(":8099")
}

func initializeGormClient() {
	config, _ := config.ExtractConfiguration()
	create.DBClient = &database.GormClient{}
	create.DBClient.ConnectToDatabase(config)
}
