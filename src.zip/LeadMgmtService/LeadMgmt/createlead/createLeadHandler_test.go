package createlead_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"strings"
	"github.com/labstack/echo"
	"github.com/stretchr/testify/assert"
	"LeadMgmtService/LeadMgmt/createlead"
	model "LeadMgmtService/LeadMgmt/model"
	"LeadMgmtService/lib/database"
)

var mockRepo *database.MockGormClient

//-----------------------------------------------------------------------------------------------------------------------//

//TestCreateLeadHandler method tests for StatusOK
func TestCreateLeadHandlerSuccess(t *testing.T) {

	leadJSON:=`{
		"primaryUser": {
		  "username": "string",
		  "firstName": "string",
		  "lastName": "string",
		  "phone": "string",
		  "email": "string",
		  "userStatus": false,
		  "customNotes": "string"
		},
		"secondaryUser": {
		  "username": "string",
		  "firstName": "string",
		  "lastName": "string",
		  "phone": "string",
		  "email": "string",
		  "userStatus": false,
		  "customNotes": "string"
		},
		"assignedTo": {
		  "userId": 999,
		  "companyId": 999
		},
		"address": {
		  "evMeasurementStatus": "string",
		  "addressLine1": "string",
		  "addressLine2": "string",
		  "city": "string",
		  "state": "string",
		  "zip": 2222
		},
		"leadDetails": {
		  "leadId": 999,
		  "leadStatus": "Lead",
		  "leadArchived": "Lost Opportunity",
		  "leadArchivedOther": "string",
		  "projectType": "Full Install",
		  "jobType": "Residential",
		  "structureType": "Primary Structure",
		  "leadSource": "Yellow Pages",
		  "dollarSize": "string"
		}
	}`
	
	lead := model.Lead{
		JobType:              "Residential",
		Status:               "Lead",
		LeadSource:           "Yellow Pages",
		CompanyId:            999,
		AssignedTo:           999,
		StructureType:        "Primary Structure",
		DollarSize:           "string",
		LeadArchivedOther:    "Lost Opportunity",
		ProjectType:          "Full Install",
	}

	address := model.Address{
		EvMeasurementStatus: "string",
		AddressLine1:        "string",
		AddressLine2:        "string",
		City:                "string",
		State:               "string",
		Zip:                 2222,
	}

	primaryhomeowner := model.Homeowner{
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	}

	Secondaryhomeowner := model.Homeowner{
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	}

	mockRepo = &database.MockGormClient{}
	
	mockRepo.On("CreateAddressQuery", address).Return(model.Address{
		
		EvMeasurementStatus: "string",
		AddressLine1:        "string",
		AddressLine2:        "string",
		City:                "string",
		State:               "string",
		Zip:                 2222,
	},nil)
	mockRepo.On("CreateHomeownerQuery", primaryhomeowner).Return(model.Homeowner{
		
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	},nil)
	mockRepo.On("CreateHomeownerQuery", Secondaryhomeowner).Return(model.Homeowner{
		
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	},nil)
	mockRepo.On("CreateLeadQuery", lead).Return(nil)

	e := echo.New()
	req := httptest.NewRequest(http.MethodPost, "/v1/leadsMgmt", strings.NewReader(leadJSON))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	c := e.NewContext(req, rec)
	createlead.DBClient = mockRepo

	if assert.NoError(t, createlead.CreateLeadHandler(c)) {
		assert.Equal(t, http.StatusOK, rec.Code)
	}
}

//-----------------------------------------------------------------------------------------------------------------------//

func TestCreateLeadHandlerFailure(t *testing.T) {

	leadJSON:=`{
		"primaryUser": {
		  "username": "string",
		  "firstName": "string",
		  "lastName": "string",
		  "phone": "string",
		  "email": "string",
		  "userStatus": false,
		  "customNotes": "string"
		},
		"secondaryUser": {
		  "username": "string",
		  "firstName": "string",
		  "lastName": "string",
		  "phone": "string",
		  "email": "string",
		  "userStatus": false,
		  "customNotes": "string"
		},
		"assignedTo": {
		  "userId": 999,
		  "companyId": 999
		},
		"address": {
		  "evMeasurementStatus": "string",
		  "addressLine1": "string",
		  "addressLine2": "string",
		  "city": "string",
		  "state": "string",
		  "zip": 2222
		},
		"leadDetails": {
		  "leadId": 999,
		  "leadStatus": "status",
		  "leadArchived": "Lost Opportunity",
		  "leadArchivedOther": "string",
		  "projectType": "Full Install",
		  "jobType": "Residential",
		  "structureType": "Primary Structure",
		  "leadSource": "Yellow Pages",
		  "dollarSize": "string"
		}
	}`
	
	lead := model.Lead{
		JobType:              "Residential",
		Status:               "Lead",
		LeadSource:           "Yellow Pages",
		CompanyId:            999,
		AssignedTo:           999,
		StructureType:        "Primary Structure",
		DollarSize:           "string",
		LeadArchivedOther:    "Lost Opportunity",
		ProjectType:          "Full Install",
	}

	address := model.Address{
		EvMeasurementStatus: "string",
		AddressLine1:        "string",
		AddressLine2:        "string",
		City:                "string",
		State:               "string",
		Zip:                 2222,
	}

	primaryhomeowner := model.Homeowner{
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	}

	Secondaryhomeowner := model.Homeowner{
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	}

	mockRepo = &database.MockGormClient{}
	
	mockRepo.On("CreateAddressQuery", address).Return(model.Address{
		
		EvMeasurementStatus: "string",
		AddressLine1:        "string",
		AddressLine2:        "string",
		City:                "string",
		State:               "string",
		Zip:                 2222,
	},nil)
	mockRepo.On("CreateHomeownerQuery", primaryhomeowner).Return(model.Homeowner{
		
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	},nil)
	mockRepo.On("CreateHomeownerQuery", Secondaryhomeowner).Return(model.Homeowner{
		
		UserName:    "string",
		FirstName:   "string",
		LastName:    "string",
		Phone:       "string",
		Email:       "string",
		UserStatus:  false,
		CustomNotes: "string",
	},nil)
	mockRepo.On("CreateLeadQuery", lead).Return(nil)

	e := echo.New()
	req := httptest.NewRequest(http.MethodPost, "/v1/leadsMgmt", strings.NewReader(leadJSON))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	c := e.NewContext(req, rec)
	createlead.DBClient = mockRepo

	if assert.NoError(t, createlead.CreateLeadHandler(c)) {
		assert.Equal(t, http.StatusBadRequest, rec.Code)
	}
}

//-----------------------------------------------------------------------------------------------------------------------//
