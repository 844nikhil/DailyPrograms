/**
*
*
* @author  Nikhil Sharma
* @version v1
* @since   2019-12-06
**/

//This package defines Lead Handler Function for Creating Leads, Address and Homeowners
package createlead

import (
	"encoding/json"
	"errors"
	"net/http"
	"github.com/labstack/echo"
	model "LeadMgmtService/LeadMgmt/model"
	database "LeadMgmtService/lib/database"
	helper "LeadMgmtService/LeadMgmt/helpers"
)

//-----------------------------------------------------------------------------------------------------------------------//

var DBClient database.IPostgreClient

//This Function takes JSON Object from Front End and after Decoding it, passes it to the Query Function
func CreateLeadHandler(c echo.Context) error {

	//Initializing Variables
	lead := model.Lead{}	
	leadsMgmt := model.LeadsMgmt{}				
	response := model.ApiResponse{}
	address := model.Address{}
	primaryHomeowner := model.Homeowner{}
	secondaryHomeowner := model.Homeowner{}
	var dberr error

	//Decoding Input JSON into leadDetails variable
	errDecode := json.NewDecoder(c.Request().Body).Decode(&leadsMgmt)
	//Checking whether there are any errors while decoding the input JSON			
	if errDecode != nil {
		response = CreateResponse(errDecode)
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusBadRequest)
		return json.NewEncoder(c.Response()).Encode(response)
	}

	//Populating Respective Structs by calling their Respective Create Functions
	address=CreateAddress(leadsMgmt)
	primaryHomeowner,response=CreatePrimaryHomeowner(leadsMgmt)
	if (response != (model.ApiResponse{}) ) {
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusBadRequest)
		return json.NewEncoder(c.Response()).Encode(response)
	}
	secondaryHomeowner=CreateSecondaryHomeowner(leadsMgmt)

	//Calling Create Query Functions
	
	address,dberr = DBClient.CreateAddressQuery(address)
	primaryHomeowner,dberr = DBClient.CreateHomeownerQuery(primaryHomeowner)
	secondaryHomeowner,dberr = DBClient.CreateHomeownerQuery(secondaryHomeowner)

	//Inserting values of foreign fields(primaryHomeownerId,secondaryHomeownerId,addressId) into leads table
	leadsMgmt.PrimaryUser.HomeownerId=primaryHomeowner.HomeownerId
	leadsMgmt.SecondaryUser.HomeownerId=secondaryHomeowner.HomeownerId
	leadsMgmt.Address.AddressId=address.AddressId

	//Calling createLead function to populate leads struct which is to inserted into leads table
	lead,response=CreateLead(leadsMgmt)
	if (response != (model.ApiResponse{}) ) {
		c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
		c.Response().WriteHeader(http.StatusBadRequest)
		return json.NewEncoder(c.Response()).Encode(response)
	}
	//Calling Create Query Functions
	dberr = DBClient.CreateLeadQuery(lead)

	//Creating Response based on the output of Query Function
	response = CreateResponse(dberr)

	defer c.Request().Body.Close()
	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
	c.Response().WriteHeader(http.StatusOK)
	return json.NewEncoder(c.Response()).Encode(response)
}

//-----------------------------------------------------------------------------------------------------------------------//

//This Function is for Create Leads
func CreateLead(leadsMgmt model.LeadsMgmt) (model.Lead,model.ApiResponse) {
	
	lead := model.Lead{}
	response := model.ApiResponse{}

	lead.JobType = leadsMgmt.LeadDetails.JobType
	errJobType := helper.CheckJobType(lead.JobType)
	lead.Status = leadsMgmt.LeadDetails.LeadStatus
	errLeadStatus := helper.CheckLeadStatus(lead.Status)
	lead.ProjectType = leadsMgmt.LeadDetails.ProjectType
	errProjectType := helper.CheckProjectType(lead.ProjectType)
	//Checking whether the LeadStatus and JobType has correct value or not
	if (errJobType != nil || errLeadStatus != nil || errProjectType != nil) {
		response = CreateResponse(errors.New("Wrong Data Inserted"))
		return model.Lead{},response
	}

	lead.PrimaryHomeownerId = leadsMgmt.PrimaryUser.HomeownerId
	lead.SecondaryHomeownerId = leadsMgmt.SecondaryUser.HomeownerId
	lead.LeadSource = leadsMgmt.LeadDetails.LeadSource
	lead.CompanyId = leadsMgmt.AssignedTo.CompanyId
	lead.AssignedTo = leadsMgmt.AssignedTo.UserId
	lead.StructureType = leadsMgmt.LeadDetails.StructureType
	lead.DollarSize = leadsMgmt.LeadDetails.DollarSize
	lead.AddressId = leadsMgmt.Address.AddressId
	lead.LeadArchivedOther = leadsMgmt.LeadDetails.LeadArchived
	if(lead.LeadArchivedOther == "Other"){
		lead.LeadArchivedOther = leadsMgmt.LeadDetails.LeadArchivedOther
	}

	return lead,response
}

//This Function is for Create Primary Homeowner
func CreatePrimaryHomeowner(leadsMgmt model.LeadsMgmt) (model.Homeowner,model.ApiResponse) {
	
	homeowner := model.Homeowner{}
	response := model.ApiResponse{}

	homeowner.UserName=leadsMgmt.PrimaryUser.UserName
	homeowner.UserStatus=leadsMgmt.PrimaryUser.UserStatus
	homeowner.CustomNotes=leadsMgmt.PrimaryUser.CustomNotes
	homeowner.FirstName=leadsMgmt.PrimaryUser.FirstName
	homeowner.LastName=leadsMgmt.PrimaryUser.LastName
	homeowner.Phone=leadsMgmt.PrimaryUser.Phone
	homeowner.Email=leadsMgmt.PrimaryUser.Email
	//Checking whether the values of FirstName,LastName,Phone,Email are empty or not
	if (homeowner.FirstName == "" || homeowner.LastName == "" || homeowner.Phone == "" || homeowner.Email == "") {
		response = CreateResponse(errors.New("Data Not Inserted"))
		return model.Homeowner{},response
	}

	return homeowner,response
}

//This Function is for Create Secondary Homeowner
func CreateSecondaryHomeowner(leadsMgmt model.LeadsMgmt) (model.Homeowner) {
	
	homeowner := model.Homeowner{}

	homeowner.UserName=leadsMgmt.SecondaryUser.UserName
	homeowner.FirstName=leadsMgmt.SecondaryUser.FirstName
	homeowner.LastName=leadsMgmt.SecondaryUser.LastName
	homeowner.Phone=leadsMgmt.SecondaryUser.Phone
	homeowner.Email=leadsMgmt.SecondaryUser.Email
	homeowner.UserStatus=leadsMgmt.SecondaryUser.UserStatus
	homeowner.CustomNotes=leadsMgmt.SecondaryUser.CustomNotes

	return homeowner
}

//This Function is for Create Address
func CreateAddress(leadsMgmt model.LeadsMgmt) (model.Address) {

	address := model.Address{}

	address.EvMeasurementStatus=leadsMgmt.Address.EvMeasurementStatus
	address.AddressLine1=leadsMgmt.Address.AddressLine1
	address.AddressLine2=leadsMgmt.Address.AddressLine2
	address.City=leadsMgmt.Address.City
	address.State=leadsMgmt.Address.State
	address.Zip=leadsMgmt.Address.Zip

	return address
}

//This Function takes Error as Input and Produce Corresponding Response
func CreateResponse(err error) model.ApiResponse {

	response := model.ApiResponse{}

	if err == nil {
		response.Code = 200
		response.Type = "Success"
		response.Message = "Data Inserted Successfully"
	}else{
		response.Code = 405
		response.Type = "Wrong or No Data Inserted"
		response.Message = "Invalid Input"
	}
	return response
}
