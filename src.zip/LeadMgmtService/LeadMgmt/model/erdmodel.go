/**
*
*
* @author  Tanya Shanker
* @version v1
* @since   2019-12-06
**/


//This package defines Lead Management ERD model
package model

type Lead struct {
    Id                          int         `json:"id" gorm:"column:LeadsId;primary_key;AUTO_INCREMENT"`
    PrimaryHomeownerId          int         `json:"primaryUser" gorm:"column:PrimaryUserId"`
    SecondaryHomeownerId        int         `json:"secondaryUser" gorm:"column:SecondaryUserId"`
    JobType                     string      `json:"jobType" gorm:"column:JobType"`
    Status                      string      `json:"status" gorm:"column:Status"`
    LeadSource                  string      `json:"leadSource" gorm:"column:LeadSource"`
    CompanyId                   int         `json:"companyId" gorm:"column:CompanyId"`
    AssignedTo                  int         `json:"assignedTo" gorm:"column:AssignedTo"`
    StructureType               string      `json:"structureType" gorm:"column:StructureType"`
    DollarSize                  string      `json:"dollarSize" gorm:"column:DollarSize"`
   // Address                       Address     
    //`gorm:"foreign_key:addressId;association_foreignkey:id"`
    AddressId                   int         `json:"addressId" gorm:"column:AddressId"`
    LeadArchivedOther           string      `json:"leadArchivedOther" gorm:"column:LeadArchivedOther"`
    ProjectType                 string      `json:"projectType" gorm:"column:ProjectType"`
}


//--------------------------------------------------------------------------------------------------------------------------//


type Address struct{
    AddressId            int      `json:"addressId" gorm:"column:AddressId;primary_key;AUTO_INCREMENT"`
    EvMeasurementStatus  string   `json:"evMeasurementStatus" gorm:"column:EvMeasurementStatus"`
    AddressLine1         string   `json:"addressLine1" gorm:"column:AddressLine1"`
    AddressLine2         string   `json:"addressLine2" gorm:"column:AddressLine2"`
    City                 string   `json:"city" gorm:"column:City"` 
    State                string   `json:"state" gorm:"column:State"`
    Zip                  int      `json:"zip" gorm:"column:Zip"`
}


//--------------------------------------------------------------------------------------------------------------------------//


type Homeowner struct {
    HomeownerId     int         `json:"homeownerId" gorm:"column:HomeownerID;primary_key;AUTO_INCREMENT"`
    UserName        string      `json:"username" gorm:"column:UserName"`
    FirstName	    string      `json:"firstName" gorm:"column:FirstName"`
    LastName	    string      `json:"lastName" gorm:"column:LastName"`
    Phone	        string      `json:"phone" gorm:"column:Phone"`
    Email	        string      `json:"email" gorm:"column:Email"`
    UserStatus	    bool 	    `json:"userStatus" gorm:"column:UserStatus"`
    CustomNotes     string      `json:"customNotes" gorm:"column:CustomNotes"`
}


//--------------------------------------------------------------------------------------------------------------------------//


type User struct{
    UserId          int      `json:"userId" gorm:"column:UserId;primary_key;AUTO_INCREMENT"`
    CompanyId       int      `json:"companyId" gorm:"column:CompanyId"`
}


//--------------------------------------------------------------------------------------------------------------------------//


