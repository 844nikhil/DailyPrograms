/**
*
*
* @author  Tanya Shanker
* @version v1
* @since   2019-12-06
**/


//This package defines Lead Management json data model
package model

type ApiResponse struct {
	Code            int 		 `json:"code"`
    Type            string 		 `json:"type"`
    Message         string 		 `json:"message"`
}


//--------------------------------------------------------------------------------------------------------------------------//


type LeadDetails struct{
    LeadId                      int           `json:"leadId"`
    LeadStatus                  string        `json:"leadStatus"`
    LeadArchived                string        `json:"leadArchived"`
    LeadArchivedOther           string        `json:"leadArchivedOther"`
    JobType                     string        `json:"jobType"`
    StructureType				string		  `json:"structureType"` 
	LeadSource                  string        `json:"leadSource"`
    DollarSize					string		  `json:"dollarSize"` 
	ProjectType                 string        `json:"projectType"`
}


//--------------------------------------------------------------------------------------------------------------------------//

type LeadsMgmt struct {
    PrimaryUser         Homeowner         `json:"primaryUser"`
    SecondaryUser       Homeowner         `json:"secondaryUser"` 
	AssignedTo			User		      `json:"assignedTo"` 
	Address				Address		      `json:"address"` 
	LeadDetails			LeadDetails		  `json:"leadDetails"` 
}

//--------------------------------------------------------------------------------------------------------------------------//
