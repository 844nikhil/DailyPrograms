//This package tests the Helpers Methods
package helpers_test

import (
	"errors"
	"testing"
	"github.com/stretchr/testify/assert"
	helper "LeadMgmtService/LeadMgmt/helpers"
)


//These below Testcases checks whether you are getting correct Jobtype or not
func TestCheckJobTypeSuccess(t *testing.T) {
	jobType := "Residential"
	result := helper.CheckJobType(jobType)
	assert.Equal(t, nil, result)
}

func TestCheckJobTypeFailure(t *testing.T) {
	jobType := " "
	var expected error
	expected = errors.New("Wrong Data Inserted")
	result := helper.CheckJobType(jobType)

	assert.Equal(t, expected, result)
}

//-----------------------------------------------------------------------------------------------------------------------//

//These below Testcases checks whether you are getting correct LeadStatus or not
func TestCheckLeadStatusSuccess(t *testing.T) {
	leadStatus := "Deleted"
	result := helper.CheckLeadStatus(leadStatus)

	assert.Equal(t, nil, result)
}

func TestCheckLeadStatusFailure(t *testing.T) {
	leadStatus := ""
	var expected error
	expected = errors.New("Wrong Data Inserted")
	result := helper.CheckLeadStatus(leadStatus)

	assert.Equal(t, expected, result)
}

//These below Testcases checks whether you are getting correct ProjectType or not
func TestCheckProjectTypeSuccess(t *testing.T) {
	projectType := "Full Install"
	result := helper.CheckProjectType(projectType)

	assert.Equal(t, nil, result)
}

func TestCheckProjectTypeFailure(t *testing.T) {
	projectType := ""
	var expected error
	expected = errors.New("Wrong Data Inserted")
	result := helper.CheckProjectType(projectType)

	assert.Equal(t, expected, result)
}