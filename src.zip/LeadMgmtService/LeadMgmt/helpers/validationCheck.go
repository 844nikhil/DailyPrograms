//This package defines Lead Handler Function for Creating Leads
package helpers

import (
	"errors"
)

//This function Checks Whether the Value of JobType is from given Input Values or not
func CheckJobType(jobType string) error {
	if (jobType == "Residential" || jobType == "commercial") {
		return nil
	} else {
		return errors.New("Wrong Data Inserted")
	}
}

//This function Checks Whether the Value of LeadStatus is from given Input Values or not
func CheckLeadStatus(leadStatus string) error {
	if (leadStatus == "Lead" || leadStatus == "Opportunity" || leadStatus == "On Hold" || leadStatus == "Archived" || leadStatus == "Deleted") {
		return nil
	} else {
		return errors.New("Wrong Data Inserted")
	}
}

//This function Checks Whether the Value of ProjectType is from given Input Values or not
func CheckProjectType(projectType string) error {
	if (projectType == "Full Install" || projectType == "Partial Replacement" || projectType == "Minor Repair" || projectType == "Gutters" || projectType == "Non-Roof Job") {
		return nil
	} else {
		return errors.New("Wrong Data Inserted")
	}
}