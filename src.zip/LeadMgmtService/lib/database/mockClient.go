package database

import (
	"github.com/stretchr/testify/mock"
	model "LeadMgmtService/LeadMgmt/model"
	"LeadMgmtService/lib/configuration"
)

//MockGormClient is a mock implementation of a datastore client for testing purposes
type MockGormClient struct {
	mock.Mock
}

//ConnectToDatabase mock
func (m *MockGormClient) ConnectToDatabase(config configuration.ServiceConfig) {
	//Does nothing
}

//CreateLeadQuery mock
func (m *MockGormClient) CreateLeadQuery(lead model.Lead) (error) {
	args := m.Mock.Called(lead)
	return args.Error(0)
}

//CreateAddressQuery mock
func (m *MockGormClient) CreateAddressQuery(address model.Address) (model.Address,error) {
	args := m.Mock.Called(address)
	return args.Get(0).(model.Address),args.Error(1)
}

//CreateHomeownerQuery mock
func (m *MockGormClient) CreateHomeownerQuery(homeowner model.Homeowner) (model.Homeowner,error) {
	args := m.Mock.Called(homeowner)
	return args.Get(0).(model.Homeowner),args.Error(1)
}

