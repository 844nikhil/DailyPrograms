/**
* 
*
* @author  Tanya Shanker
* @version v1
* @since   2019-22-05
*/

//This package defines creation of tables related to Lead Management
package database

import(
	model "LeadMgmtService/LeadMgmt/model"
)

//var DBClient IPostgreClient


//--------------------------------------------------------------------------------------------------------------------------//

//This function creates the tables in the database
func (gc *GormClient) CreateLeadTable() {

	 gc.GormDB.AutoMigrate(&model.Lead{}, &model.Homeowner{}, &model.User{}, &model.Address{})
	 //gc.GormDB.Debug().Model(&model.Lead{}).AddForeignKey("AddressID", "addresses(AddressID)","RESTRICT","RESTRICT")
	 
}


//--------------------------------------------------------------------------------------------------------------------------//
