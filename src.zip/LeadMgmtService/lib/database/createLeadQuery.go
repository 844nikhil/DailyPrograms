/**
*
*
* @author  Nikhil Sharma
* @version v1
* @since   2019-12-06
 */

//This package Contains the Query for Inserting Data
package database

import (
	model "LeadMgmtService/LeadMgmt/model"
)

//-----------------------------------------------------------------------------------------------------------------------//

//To Insert into lead
func (gc *GormClient) CreateLeadQuery(lead model.Lead) error {
	dberr := gc.GormDB.Debug().Create(&lead).Error
	return dberr
}

//To Insert into Address
func (gc *GormClient) CreateAddressQuery(address model.Address) (model.Address,error) {
	lastAddress := model.Address{}
	dberr := gc.GormDB.Debug().Create(&address).Error
	gc.GormDB.Last(&lastAddress)
	return lastAddress,dberr
}

//To Insert into Homeowner
func (gc *GormClient) CreateHomeownerQuery(homeowner model.Homeowner) (model.Homeowner,error) {
	lastHomeowner := model.Homeowner{}
	dberr := gc.GormDB.Debug().Create(&homeowner).Error
	gc.GormDB.Last(&lastHomeowner)
	return lastHomeowner,dberr
}