package database

import (
	"LeadMgmtService/lib/configuration"

	"fmt"
	"log"

	"github.com/jinzhu/gorm"
	//pq is the driver
	_ "github.com/lib/pq"
	model "LeadMgmtService/LeadMgmt/model"
)

//IPostgreCLient is an interface with the methods to be implemented later
type IPostgreClient interface {
	ConnectToDatabase(config configuration.ServiceConfig)
	//CreateLeadTable()
	CreateLeadQuery(lead model.Lead) (error)
	CreateHomeownerQuery(homeowner model.Homeowner) (model.Homeowner,error)
	CreateAddressQuery(address model.Address) (model.Address,error)
}

//GormClient is the real implementation of IPostgreCLient
type GormClient struct {
	GormDB *gorm.DB
}

//ConnectToDatabase defines connection with the database
func (gc *GormClient) ConnectToDatabase(config configuration.ServiceConfig) {
	var err error
	dbinfo := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable",
		config.HOST, config.DB_USER, config.DB_PASSWORD, config.DB_NAME, config.PORT)
	gc.GormDB, err = gorm.Open("postgres", dbinfo)
	if err != nil {
		fmt.Println(err)
	}else{
		log.Printf("Postgres started at %s PORT", config.PORT)
	}
	
}
