/**
* 
*
* @author  Capgemini
* @version v1
* @since   2019-21-05
*/

//This package defines database configuration
package configuration

import (
	"encoding/json"
	"fmt"
	"os"
)


//--------------------------------------------------------------------------------------------------------------------------//


type ServiceConfig struct {
	DB_USER			string		`json:"dbUser"`
	DB_PASSWORD		string		`json:"dbPassword"`
	DB_NAME			string		`json:"dbName"`
	PORT			string		`json:"port"`
	HOST			string		`json:"host"`
}


//--------------------------------------------------------------------------------------------------------------------------//


//To extract the database configuration fields from json file
func ExtractConfiguration() (ServiceConfig, error) {
	
	conf := ServiceConfig{
	}

	gopath := os.Getenv("GOPATH")
	filepath := gopath+`\src\LeadMgmtService\lib\configuration\config.json`
	file, err := os.Open(filepath)
	if err != nil {
		fmt.Println("Configuration file not found. Continuing with default values.")
		fmt.Println(err)
		return conf,err
	}

	err = json.NewDecoder(file).Decode(&conf)
	return conf, err
}



//--------------------------------------------------------------------------------------------------------------------------//

