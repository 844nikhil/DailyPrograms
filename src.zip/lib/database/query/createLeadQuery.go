package query

import (
	model "LeadMgmt/ev_lm_model"
)

func CreateLeadQuery(lead model.Lead, response model.ApiResponse) (model.ApiResponse) {
	dBerr:=db.Create(&lead).Error
	if(dBerr!=nil){
		response.Code=400
        response.Type=dBerr.Error()
		response.Message="Data Insertion Failed"
		return response
	}else{
		response.Code=200
        response.Type="Success"
		response.Message="OK"
		return response
	}	
}