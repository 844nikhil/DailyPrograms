package query_test

import(
	"github.com/stretchr/testify/assert"
	"testing"
	model "LeadMgmt/ev_lm_json"
	query "lib/database/query"
    config "lib/configuration"
    db "lib/database/dbLayer"	
)

func TestCreateLeadSuccess(t *testing.T){
	config, _ := config.ExtractConfiguration()
	connection := db.ConnectToDatabase(config)
	defer connection.Close()

	expected := model.ApiResponse{
		Code : 200,
		Type : "Success",
		Message : "OK",
	}
	lead := model.Lead{
		Id : "1222",
		PrimaryUser : "1222",
		SecondaryUser : "1222",
    	JobType : "string",
		LeadStatus : "string", 	
		LeadSource : "string",
		AssignedTo : "1222",
    	Address : "1222",
        Status : "converted",
        CompanyId : "1222",
	}
	result := query.CreateLeadQuery(lead)

	assert.Equal(t,expected,result)
}

func TestCreateLeadFail(t *testing.T){
	config, _ := config.ExtractConfiguration()
	connection := db.ConnectToDatabase(config)
	defer connection.Close()

	expected := model.ApiResponse{
		Code : 400,
		Type : "pq: duplicate key value violates unique constraint \"leads_pkey\"",
		Message : "ID Already Exists",
	}
	lead := model.Lead{
		Id : "1222",
		PrimaryUser : "1222",
		SecondaryUser : "1222",
    	JobType : "string",
		LeadStatus : "string", 	
		LeadSource : "string",
		AssignedTo : "1222",
    	Address : "1222",
        Status : "converted",
        CompanyId : "1222",
	}
	result := query.CreateLeadQuery(lead)

	assert.Equal(t,expected,result)
}

/*func TestCreateLeadInvalidInput(t *testing.T){
	config, _ := config.ExtractConfiguration()
	connection := db.ConnectToDatabase(config)
	defer connection.Close()

	expected := model.ApiResponse{
		Code : 400,
		Type : "",
		Message : "Invalid Input",
	}
	lead := model.Lead{
		Id : "1222",
		PrimaryUser : "1222",
		SecondaryUser : "1222",
    	JobType : "string",
		LeadStatus : "string", 	
		LeadSource : "string",
		AssignedTo : "1222",
    	Address : "1222",
        Status : "converted",
        CompanyId : "1222",
	}
	result := query.CreateLeadQuery(lead)

	assert.Equal(t,expected,result)
}*/