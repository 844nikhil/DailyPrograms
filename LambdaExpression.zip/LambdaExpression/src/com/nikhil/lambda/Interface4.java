package com.nikhil.lambda;

public interface Interface4 {

	void display(String name);
}
