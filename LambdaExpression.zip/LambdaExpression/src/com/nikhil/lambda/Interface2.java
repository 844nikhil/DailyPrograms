package com.nikhil.lambda;

@FunctionalInterface
interface Interface2 {

	//A method with single parameter
    public int incrementByFive(int a);
}