package com.nikhil.lambda;


@FunctionalInterface
interface MyFunctionalInterface {

	//A method with no parameter
    public String sayHello();
}