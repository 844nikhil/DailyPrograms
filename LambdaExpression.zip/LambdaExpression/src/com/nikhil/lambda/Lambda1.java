package com.nikhil.lambda;


public class Lambda1 {

   public static void main(String args[]) {
        // lambda expression
	   MyFunctionalInterface msg = () ->  "Hello";
    	
        System.out.println(msg.sayHello());
    }
}