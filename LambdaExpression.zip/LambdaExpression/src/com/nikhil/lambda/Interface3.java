package com.nikhil.lambda;

public interface Interface3 {

	public String sconcat(String a, String b);
}
