package com.nikhil.lambda;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReferenceToInstanceMethod {

	



		public static void main(String[] args) {

			List<Person> person=new ArrayList<Person>();
			person.add(new Person("Nikhil",22));
			person.add(new Person("Saifi",11));
			person.add(new Person("Tanya",45));
			
			List<String> personList=ReferenceToInstanceMethod.getPersonName(person,Person::getName);
			personList.forEach(System.out::println);
			
			
			System.out.println("-----------------");
			person.forEach(System.out::println);
			System.out.println("-----------------");		
			ExecutorService executorService = Executors.newSingleThreadExecutor();
			
			Runnable command = ReferenceToInstanceMethod::myRun;
			executorService.execute(command);
			System.out.println("-----------------");		
			List<Integer> numbers = Arrays.asList(4,9,25,36,100);
			numbers.forEach(System.out::println);
			System.out.println("-----------------");
			
			List<Double> findSquareRoots = ReferenceToInstanceMethod.findSquareRoot(numbers);
			findSquareRoots.forEach(System.out::println);
			
			
		}

		private static List<Double> findSquareRoot(List<Integer> numbers) {
			
			List<Double> results = new ArrayList<>();
			numbers.forEach(x->results.add(Math.sqrt(x)));
			
			return results;
		}

		private static List<String> getPersonName(List<Person> person, Function<Person,String> f) {
			
			List<String> result=new ArrayList<String>();
			person.forEach(n ->result.add(f.apply(n)));
			
			return result;
		}
		
		public static void myRun() {
			System.out.println("My task is running");
		}
		
		}




