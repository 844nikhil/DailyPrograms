package com.nikhil.lambda;

public class LambdaWithOneParameter {

	   public static void main(String args[]) {
	        // lambda expression with single parameter num
		   
	    	Interface2 f = (num) -> num+5;
	        System.out.println(f.incrementByFive(22));
	    }
	}