package com.capgemini.customer;

import com.capgemini.bank.BankAccount;
import com.capgemini.bank.BankAccountList;
import com.capgemini.bank.BankAccountListv2;
import com.capgemini.bank.BankAccountListv3;
import com.capgemini.bank.BankAccountListv5;

public class Customer {

	public static void main(String[] args) {
		
////		BankAccount acc=null;
////		acc=new SavingAccount();
////		acc.withdraw(5000);
////		
//		InsuranceInterface insuranceInterface=null;
//		insuranceInterface=new SavingAccountv2();
//		System.out.println("Saving Account-");
//		System.out.println(insuranceInterface.insuranceName("icici policy"));
//		System.out.println(insuranceInterface.insuranceAmount(50000));
//		System.out.println(insuranceInterface.isLifeTime());
//		
//		insuranceInterface=new CurrentAccountv2();
//		System.out.println("Current Account-");
//		System.out.println(insuranceInterface.insuranceName("sbi policy"));
//		System.out.println(insuranceInterface.insuranceAmount(100000));
//		System.out.println(insuranceInterface.isLifeTime());
////		SavingAccount acc1 = new SavingAccount();
////		acc1.deposit(20000);
////		acc1.withdraw(5000);
////		SavingAccount acc2 = new SavingAccount();
////		acc2.deposit(20000);
////		SavingAccount acc3 = new SavingAccount();
////		acc3.deposit(20000);
////
////		System.out.println("Bank Account 1- " + acc1);
////		System.out.println("Bank Account 2- " + acc2);
////		System.out.println("Bank Account 3- " + acc3);
//		BankAccountList accounts=new BankAccountList();
//        BankAccount acc1=new BankAccount("Nikhil",10000);
//        BankAccount acc2=new BankAccount("Saifi",10000);
//        BankAccount acc3=new BankAccount("Vishnu",10000);
//        
//
//        accounts.addAccount(acc1);
//        accounts.addAccount(acc2);
//        accounts.addAccount(acc3);
//        
//        
//        //accounts.getAllAccount();
//        for(BankAccount acc:accounts.getAllAccount())
//               System.out.println(acc);
//        accounts.updateAccount(3, "Tanya");
//        accounts.getAllAccount();
//        for(BankAccount acc:accounts.getAllAccount())
//               System.out.println(acc);
//        
//        System.out.println(accounts.getAccountById(2));
//        
//        
//        accounts.removeAccountById(3);
//        accounts.getAllAccount();
		
		
//        BankAccountListv2 accounts=new BankAccountListv2();
//        BankAccount acc1=new BankAccount("Nikhil",10000);
//        BankAccount acc2=new BankAccount("Ashish",10000);
//        BankAccount acc3=new BankAccount("Vishnu",10000);
//        BankAccount acc4=new BankAccount("Saifi",10000);
//        BankAccount acc5=new BankAccount("Karthik",10000);
//        
//        accounts.addAccount(acc1);
//        accounts.addAccount(acc2);
//        accounts.addAccount(acc3);
//        accounts.addAccount(acc4);
//        accounts.addAccount(acc5);
//        
//        //accounts.getAllAccount();
//        
//        System.out.println(accounts.getAllAccount());
//        System.out.println(accounts.updateAccount(4,"Angshu"));
//        System.out.println(accounts.removeAccountById(4));
//        
//        System.out.println(accounts.sortByNameVer2());
        
        BankAccountListv5 accounts=new BankAccountListv5();
        BankAccount acc1=new BankAccount("Nikhil",10000);
        BankAccount acc2=new BankAccount("Ashish",10000);
        BankAccount acc3=new BankAccount("Vishnu",10000);
        BankAccount acc4=new BankAccount("Saifi",10000);
        BankAccount acc5=new BankAccount("Karthik",10000);
        
        accounts.addAccount(acc1);
        accounts.addAccount(acc2);
        accounts.addAccount(acc3);
        accounts.addAccount(acc4);
        accounts.addAccount(acc5);
        
        //accounts.getAllAccount();
        
        System.out.println(accounts.getAllAccount());
        System.out.println(accounts.updateAccount(4,"Angshu"));
        System.out.println(accounts.removeAccountById(4));
        
        //System.out.println(accounts.sortByNameVer2());


	}
}
