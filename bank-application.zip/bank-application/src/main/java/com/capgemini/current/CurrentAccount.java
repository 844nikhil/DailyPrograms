package com.capgemini.current;

import com.capgemini.bank.BankAccount;

public class CurrentAccount extends BankAccount{

	CurrentAccount(String accountHolderName, double accountBalance){
		super(accountHolderName,accountBalance);
	}
	
	@Override
	public void withdraw(double amount) {
		System.out.println("Current");
		
	}

	

	
	
}
