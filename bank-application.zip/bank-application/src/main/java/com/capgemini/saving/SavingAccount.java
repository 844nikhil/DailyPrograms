package com.capgemini.saving;

import com.capgemini.bank.BankAccount;

public class SavingAccount extends BankAccount{

	SavingAccount(String accountHolderName, double accountBalance) {
		super(accountHolderName,accountBalance);
	}
	@Override
	public void withdraw(double amount) {
		System.out.println("saving");
	}
	
	public void isSalaryAccount() {
		System.out.println("salary");
	}

	
	
}