package com.capgemini.bank;

public interface InsuranceInterface {

	String insuranceName(String insuranceName);
	double insuranceAmount(double insuranceAmount);
	boolean isLifeTime();
}
