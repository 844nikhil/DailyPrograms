package com.capgemini.bank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class BankAccountListv2 {

       ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();

       public void addAccount(BankAccount acc) {
              accounts.add(acc);

       }

       public ArrayList<BankAccount> removeAccountById(int accNo) {
              for (BankAccount acc : accounts) {
                     if (acc.getAccountNo() == accNo)
                           accounts.remove(acc);
              }
              return accounts;
       }

       public ArrayList updateAccount(int accNo, String accountHolderName) {
              for (BankAccount acc : accounts) {
                     if (acc.getAccountNo() == accNo) {
                           acc.setAccountHolderName(accountHolderName);
                           return accounts;
                     }
                     
              }

              throw new RuntimeException("Account does not exist");
       }

       public ArrayList<BankAccount> getAllAccount() {
              return accounts;
       }
       
       public ArrayList<BankAccount> sortByName()
       {
              Collections.sort(accounts, new Comparator<BankAccount>() {
                  public int compare(BankAccount acc1, BankAccount acc2) {
                      return acc1.getAccountHolderName().compareTo(acc2.getAccountHolderName());
                  }
              });
              return accounts;
                           
       }
       
       public ArrayList<BankAccount> sortByNameVer2()
       {
              Collections.sort(accounts,(BankAccount acc1, BankAccount acc2) -> acc1.getAccountHolderName().compareTo(acc2.getAccountHolderName()));
              return accounts;
                           
       }
       public BankAccount getAccountById(int AccNo) {
              for (BankAccount acc : accounts) {
                     if (acc.getAccountNo() == AccNo)
                           return acc;
              }
              throw new RuntimeException("Account does not exist");
       }

}

