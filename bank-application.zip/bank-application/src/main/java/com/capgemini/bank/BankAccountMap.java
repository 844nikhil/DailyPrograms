package com.capgemini.bank;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class BankAccountMap {

	HashMap<Integer, BankAccount> list;
	
	public BankAccountMap() {
		list=new HashMap<>();
	}
	
	public void addAccountForEmployee(int empId, BankAccount bankAccount) {
		list.put(empId,bankAccount);
	}
	
	public Set<Integer> getAllEmployeeId(){
		return list.keySet();
	}
	
	public  Collection<BankAccount> getAllBankAccounts(){
		return list.values();
	}
	
	public Set<Map.Entry<Integer, BankAccount>> getEmployeeDetails() {
		return list.entrySet();
	}
	
	
}
