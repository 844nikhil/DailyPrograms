package com.capgemini.bank;

public class hello {
	static int  i=0;
	hello(){
		
		System.out.println("constructor");
	}
	{
		
		System.out.println("init");
	}
	static {
		
		System.out.println("static"+i);
	}
	static void display(){
		i=1;
		System.out.println("display");
	}
	public static void main(String[] args) {
		hello h=new hello();
		hello.display();
	}
}
