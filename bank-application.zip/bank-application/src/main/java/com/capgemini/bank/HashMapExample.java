package com.capgemini.bank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<Integer, String> list = new HashMap<Integer, String>();

		list.put(1, "Nikhil");
		list.put(2, "Saifi");
		list.put(3, "Tanya");
		list.put(4, "Ashish");
		list.put(5, "Vishnu");

		System.out.println("Whole list- " + list.toString());

		System.out.println("\nIterating-\n");

		for (Map.Entry m : list.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		System.out.println("\nSize of list- " + list.size());

		list.clear();
		System.out.println("\nSize of list after clearing-" + list.size());

		list.put(1, "Nikhil");
		list.put(2, "Saifi");
		list.put(3, "Tanya");
		list.put(4, "Ashish");
		list.put(5, "Vishnu");

		System.out.println();

		for (Map.Entry m : list.entrySet()) {
			System.out.println("Only getting Keys- " + m.getKey());
		}

		System.out.println();

		for (Map.Entry m : list.entrySet()) {
			System.out.println("Only getting Values- " + m.getValue());
		}

		//by keys
		List<Integer> sortedListByKeys = new ArrayList<Integer>(list.keySet());
		Collections.sort(sortedListByKeys);
		System.out.println("\nSorted List via keys- ");
		for (Integer i : sortedListByKeys) {
			System.out.println(i);
		}

		//by values
		List<String> sortedListByValue = new ArrayList<String>(list.values());
		Collections.sort(sortedListByValue);
		System.out.println("\nSorted List via keys- ");
		for (String i : sortedListByValue) {
			System.out.println(i);
		}
		
		
	}
}
