package com.capgemini.bank;

public class BankAccountList {

       BankAccount accounts[] = new BankAccount[10];
       static int accountCount = 0;

       public void addAccount(BankAccount acc) {
              accounts[accountCount++] = acc;

       }

       public BankAccount[] removeAccountById(int accNo) {
              for(int index=0; index<=accountCount; index++) {
                           
              if (accounts[index].getAccountNo() == accNo) {
                     for(int shiftIndex=index; shiftIndex<accounts.length-1; shiftIndex++ )
                           {
                           accounts[shiftIndex]=accounts[shiftIndex+1];
                     
                           }
              accountCount--;
              }
       }
              return accounts;
       }

       public BankAccount[] updateAccount(int accNo, String accountHolderName) {
              for(int index=0; index<accounts.length; index++) {
                     
                     if (accounts[index].getAccountNo() == accNo) {
                           accounts[index].setAccountHolderName(accountHolderName);
                           return accounts;
                     }
              }

                     throw new RuntimeException("Account does not exist");
       }

       public BankAccount[] getAllAccount() {
              return accounts;
       }

       public BankAccount getAccountById(int AccNo) {
              for(BankAccount acc: accounts) {
                     if(acc.getAccountNo()==AccNo)
                           return acc;
              }
              throw new RuntimeException("Account does not exist");
       }
                     

}
