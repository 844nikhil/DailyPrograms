package com.nikhil.logging;

public class CarServiceRunner {
	public static void main(String[]args) {
		
		CarService carService =  new CarService();
		carService.process("Lamborghini");
	}
}
