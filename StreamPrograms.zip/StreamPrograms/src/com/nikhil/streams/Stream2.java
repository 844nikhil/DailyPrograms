package com.nikhil.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Stream2 {

	public static void main(String[] args) {
		
		Stream<String> build=Stream.<String>builder().add("k").add("pk").add("c").build();
		build.forEach(System.out::println);
		
		System.out.println("--------------------");
		
		Stream<String> limit=Stream.generate(()->"Hello").limit(2);
		limit.forEach(System.out::println);
		
		System.out.println("--------------------");
		
		Stream<Integer> limit2=Stream.iterate(10, i->i+2).limit(10);
		limit2.forEach(System.out::println);
		
		System.out.println("--------------------");
		
		IntStream range=IntStream.range(1,6);
		range.forEach(System.out::println);
		
		System.out.println("--------------------");
		
		IntStream range2=IntStream.rangeClosed(1,6);
		range2.forEach(System.out::println);
		
		System.out.println("--------------------");
		
		List<String> list=Arrays.asList("Abc1","bbbb","cccc");
		long size=list.stream().skip(1).map(element->element.substring(0, 3)).sorted().count();
		System.out.println(size);
		
		System.out.println("--------------------");
		
		
		
		System.out.println("--------------------");
		
		
		System.out.println("--------------------");
		
	}
}
