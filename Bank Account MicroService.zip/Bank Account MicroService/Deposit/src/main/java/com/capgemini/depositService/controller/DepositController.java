package com.capgemini.depositService.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.depositService.service.DepositService;

@RestController
public class DepositController {

	@Autowired
	DepositService service;
	
	
	@PutMapping("/deposit/{id}")
	public void deposit(@PathVariable("id") Object id, @RequestParam("accountNo") int accNo, @RequestParam("amount") double amount)
	{
		service.deposit(accNo, amount);
	}
	
	
}
