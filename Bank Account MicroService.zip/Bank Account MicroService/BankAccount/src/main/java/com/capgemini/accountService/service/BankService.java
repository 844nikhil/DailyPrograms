package com.capgemini.accountService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.accountService.model.BankAccount;
import com.capgemini.accountService.repository.BankRepository;

@Service
public class BankService {

	@Autowired
	BankRepository repo;
	
	public void create(BankAccount account) {
		
		repo.save(account);
	}
	
	public double getBalance(int accNo)
	{
		BankAccount acc=repo.findByAccountNo(accNo);
		return acc.getAccountBalance();
		
		
	}
	

}
