package com.capgemini.withdrawService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.withdrawService.model.BankAccount;

@Repository
public interface WithdrawRepository extends MongoRepository<BankAccount, String>{

	BankAccount findByAccountNo(int accNo);

}
