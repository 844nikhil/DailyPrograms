package com.capgemini.withdrawService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.withdrawService.service.WithdrawService;


@RestController
public class WithdrawController {

	@Autowired
	WithdrawService service;
	
	
	@PutMapping("/deposit/{id}")
	public void deposit(@PathVariable("id") Object id, @RequestParam("accountNo") int accNo, @RequestParam("amount") double amount)
	{
		service.withdraw(accNo, amount);
	}
	
	
}
