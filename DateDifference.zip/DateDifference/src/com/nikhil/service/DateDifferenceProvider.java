package com.nikhil.service;

import com.nikhil.pojo.MyDate;

public class DateDifferenceProvider {

	public int getDateDifference(MyDate startDate, MyDate endDate) {
		int days = 0;
		int daysInInitialYear = 0;
		int daysInYears=0;
		
		daysInInitialYear = daysInInitialYear(startDate, endDate);
		daysInYears =daysInIntervingYear(startDate, endDate);
		
		days = daysInMonth(startDate, endDate);
		if(days==0)
			days=endDate.getDd()-startDate.getDd();
		else
			days = days - startDate.getDd() + endDate.getDd();

		return (days + daysInInitialYear+daysInYears);
	}

	public int daysInInitialYear(MyDate startDate, MyDate endDate) {
		int daysInYear = 0;
		if (isLeapYear(startDate.getYyyy())) {
			daysInYear = daysInYear + 1;
		}
		System.out.println("daysInInitialYear"+daysInYear);
		
		return daysInYear;
	}

	public int daysInIntervingYear(MyDate startDate, MyDate endDate) {
		int daysInYear=0;
		for (int y = startDate.getYyyy() + 1; y <= endDate.getYyyy(); y++) {
			if (isLeapYear(y))
				daysInYear = 366 + daysInYear;
			else
				daysInYear = 365 + daysInYear;
		}
		System.out.println("daysInIntervingYear"+daysInYear);
		return daysInYear;
	}

	public int daysInMonth(MyDate startDate, MyDate endDate) {
		int days = 0;
		for (int i = startDate.getMm(); i < endDate.getMm(); i++) {
			if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12) {
				days = 31 + days;
			} else if (i == 2)
				days = 28 + days;
			else
				days = 30 + days;
		}
		System.out.println("daysInMonth"+days);
		return days;
	}
	
	public boolean isLeapYear(int year) {
		if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
			return true;
		return false;
	}

}