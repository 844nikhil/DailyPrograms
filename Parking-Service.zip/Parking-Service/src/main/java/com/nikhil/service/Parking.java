package com.nikhil.service;

import java.util.Map;

import com.nikhil.model.Customer;

public class Parking {

	public static void main(String[] args) {
		ParkingService parkingService=new ParkingService();
		Customer cust=new Customer("Nikhilfgh","9540752995","6");
		parkingService.addCar(new Customer("Nikhil","9540752995","6"));
		
		parkingService.addCar(new Customer("Saifi","999999999","9"));
		parkingService.addCar(new Customer("Tanya","88888888888","8"));
		parkingService.addCar(new Customer("Ashish","777777777","6"));
		parkingService.addCar(new Customer("vishnu","6666666666","6"));
		parkingService.addCar(new Customer("sparsh","5555555555","6"));
		parkingService.addCar(new Customer("karthik","4444444444","6"));
		parkingService.addCar(new Customer("ramya","3333333333","6"));
		parkingService.addCar(new Customer("ram1","22222222","6"));
		parkingService.addCar(new Customer("ram2","1111111111","6"));
		parkingService.addCar(new Customer("ram3","000000000","6"));
		parkingService.addCar(cust);
		parkingService.addCar(new Customer("mohan","777777777","6"));
		parkingService.addCar(new Customer("sohan","777777777","6"));
		parkingService.addCar(new Customer("rahul","777777777","6"));
		parkingService.addCar(new Customer("kl rahul","777777777","6"));
		
//		System.out.println(parkingService.getAllCars());
		
		for (Map.Entry m :parkingService.getAllCars() ) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
		
		System.out.println(parkingService.getCarById(cust.getId()));
		//System.out.println(cust.getId());
	}
}
