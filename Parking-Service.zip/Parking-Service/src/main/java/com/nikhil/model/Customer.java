package com.nikhil.model;

public class Customer {

	String customerName;
	String customerPhone;
	String time;
	GenerateId id;
		
	public Customer() {
		
	}
	
	public Customer(String customerName, String customerPhone, String time) {
		super();
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.time = time;
	}
	
	
	public GenerateId getId() {
		return id;
	}

	public void setId(GenerateId id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", customerPhone=" + customerPhone + ", time=" + time + "]";
	}
	
	
}
