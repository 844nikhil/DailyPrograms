package com.nikhil.model;

public class GenerateId {

	int compartment;
	int section;
	int floor;
	
	public GenerateId() {
		
	}
	
	public GenerateId(int compartment, int section, int floor) {
		super();
		this.compartment = compartment;
		this.section = section;
		this.floor = floor;
	}
	
	public int getCompartment() {
		return compartment;
	}
	public void setCompartment(int compartment) {
		this.compartment = compartment;
	}
	public int getSection() {
		return section;
	}
	public void setSection(int section) {
		this.section = section;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}

	@Override
	public String toString() {
		return compartment+""+section+""+floor;
	}
	
	
}
